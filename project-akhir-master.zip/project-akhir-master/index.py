import os

def d_dtcn():
		os.system("streamlit run model.py")
		exit()